﻿using System;

namespace NLog.Targets.SignalR.AspNetServer
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}